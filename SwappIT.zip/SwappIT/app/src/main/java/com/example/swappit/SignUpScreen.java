package com.example.swappit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SignUpScreen extends AppCompatActivity {

    //variables for log in btn
    Button btnSign;
    TextView txtLog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_screen);

        //calling ids
        btnSign = findViewById(R.id.btnSignUp);
        txtLog = findViewById(R.id.txtLogIn);

        //setting on click on txt sign up here
        txtLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent (SignUpScreen.this,LogInScreen.class);
                startActivity(intent);
            }
        });
    }
}